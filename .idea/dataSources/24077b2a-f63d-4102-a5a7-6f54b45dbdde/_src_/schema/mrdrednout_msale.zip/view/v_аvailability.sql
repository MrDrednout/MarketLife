CREATE VIEW `v_аvailability` AS
  SELECT
    `a`.`id_goods`    AS `id_goods`,
    `ds`.`termin`     AS `stock`,
    `a`.`count_goods` AS `count_goods`
  FROM (`mrdrednout_msale`.`AVAILABILITY` `a` LEFT JOIN `mrdrednout_msale`.`DICT` `ds`
      ON (((`a`.`id_stock` = `ds`.`code`) AND (`ds`.`id_dict` = 5))))