CREATE VIEW `v_sum_availability` AS
  SELECT
    `v_аvailability`.`id_goods`         AS `id_goods`,
    sum(`v_аvailability`.`count_goods`) AS `sum_goods`
  FROM `mrdrednout_msale`.`v_аvailability`
  GROUP BY `v_аvailability`.`id_goods`