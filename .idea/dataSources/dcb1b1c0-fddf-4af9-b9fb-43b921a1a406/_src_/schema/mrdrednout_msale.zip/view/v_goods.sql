CREATE VIEW `v_goods` AS
  SELECT
    `g`.`id_goods`       AS `id_goods`,
    `g`.`name_goods`     AS `name_goods`,
    `dc`.`termin`        AS `color`,
    `ds`.`termin`        AS `size`,
    `dcs`.`termin`       AS `color_string`,
    `dp`.`termin`        AS `provider`,
    `g`.`purchase_price` AS `purchase_price`,
    `g`.`cost_of`        AS `cost_of`,
    `s`.`sum_goods`      AS `sum_goods`,
    `g`.`in_arhive`      AS `in_arhive`,
    `g`.`print`          AS `print`,
    `mt`.`termin`        AS `material`,
    `tp`.`termin`        AS `type_goods`
  FROM (((((((`mrdrednout_msale`.`GOODS` `g` LEFT JOIN `mrdrednout_msale`.`DICT` `dc`
      ON (((`g`.`id_color` = `dc`.`code`) AND (`dc`.`id_dict` = 1)))) LEFT JOIN `mrdrednout_msale`.`DICT` `ds`
      ON (((`g`.`id_size` = `ds`.`code`) AND (`ds`.`id_dict` = 3)))) LEFT JOIN `mrdrednout_msale`.`DICT` `dp`
      ON (((`g`.`id_provider` = `dp`.`code`) AND (`dp`.`id_dict` = 2)))) LEFT JOIN `mrdrednout_msale`.`DICT` `dcs`
      ON (((`g`.`color_string` = `dcs`.`code`) AND (`dcs`.`id_dict` = 4)))) LEFT JOIN
    `mrdrednout_msale`.`v_sum_availability` `s` ON ((`s`.`id_goods` = `g`.`id_goods`))) LEFT JOIN
    `mrdrednout_msale`.`DICT` `tp` ON (((`tp`.`code` = `g`.`type_goods`) AND (`tp`.`id_dict` = 7)))) LEFT JOIN
    `mrdrednout_msale`.`DICT` `mt` ON (((`mt`.`code` = `g`.`material`) AND (`mt`.`id_dict` = 6))))