CREATE VIEW `v_users` AS
  SELECT
    `mrdrednout_msale`.`USERS`.`id_user`   AS `id_user`,
    `mrdrednout_msale`.`USERS`.`flg_block` AS `flg_block`,
    `mrdrednout_msale`.`USERS`.`attempt`   AS `attempt`,
    `mrdrednout_msale`.`USERS`.`password`  AS `password`,
    `mrdrednout_msale`.`USERS`.`login`     AS `login`
  FROM `mrdrednout_msale`.`USERS`